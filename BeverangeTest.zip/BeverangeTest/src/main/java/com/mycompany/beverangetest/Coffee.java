/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.beverangetest;

/**
 *
 * @author Chamod
 */
public class Coffee extends Beverange{
     public void brew(){
        System.out.println("Adding the coffee");
    }
    public void addCondiments(){
        System.out.println("Adding suger");
    }
    public void addExtras(){
        System.out.println("adding whipped cream");
    }
    
}
