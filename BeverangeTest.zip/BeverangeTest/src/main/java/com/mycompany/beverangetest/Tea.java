/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.beverangetest;

/**
 *
 * @author Chamod
 */
public class Tea extends Beverange {
    public void brew(){
        System.out.println("Adding the tea");
    }
    public void addCondiments(){
        System.out.println("Adding lemmon");
    }
    public void addExtras(){
        System.out.println("adding honey");
    }
}
