/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.beverangetest;

/**
 *
 * @author Chamod
 
 */
import java.util.Scanner;
public class BeverangeTest {

    public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

        System.out.print("Do you want extras with your tea (yes/no)? ");
        boolean teaExtras = scanner.nextLine().trim().equalsIgnoreCase("yes");

        System.out.print("Do you want extras with your coffee (yes/no)? ");
        boolean coffeeExtras = scanner.nextLine().trim().equalsIgnoreCase("yes");

        Beverange tea = new Tea();
        tea.setWantsExtras(teaExtras);

        Beverange coffee = new Coffee();
        coffee.setWantsExtras(coffeeExtras);

        System.out.println("\nMaking tea...");
        tea.finalTemplateMethod();

        System.out.println("\nMaking coffee...");
        coffee.finalTemplateMethod();

        scanner.close();
        
    }
}
