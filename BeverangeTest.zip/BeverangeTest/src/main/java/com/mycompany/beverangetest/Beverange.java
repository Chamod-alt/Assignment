/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.beverangetest;

/**
 *
 * @author Chamod
 */
public abstract class Beverange {
    boolean wantsExtras;
    
     public final void  finalTemplateMethod(){
        boilWater();
        brew();
        pourInCup();
        addCondiments();
        if(wantsExtras){
            addExtras();
        }
    }
     
    abstract void addExtras();
    
    public void boilWater(){
        System.out.println("boil Water");
    }
    
    public void pourInCup(){
        System.out.println("pourln cup");
        
    
}
    protected abstract void brew();
    protected abstract void addCondiments();
    
   public void setWantsExtras(boolean wantsExtras){
       this.wantsExtras =wantsExtras;
   }
}
