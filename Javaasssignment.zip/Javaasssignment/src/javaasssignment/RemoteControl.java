/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaasssignment;

/**
 *
 * @author Chamod
 */
public class RemoteControl {
    private Command[] onCommands;
    private Command[] offCommands;
    private Command undoCommand;
    public RemoteControl(){
        onCommands= new Command[7];
        offCommands= new Command[7];
        
        Command noCommand=new Command(){
            public void execute(){
                
            }
            public void undo(){
                
            }
        };
        for(int i=0;i<7;i=i+1){
            onCommands[i]=noCommand;
            offCommands[i]=noCommand;
        }
        undoCommand=noCommand;
                
    }
    public void  setCommand(int slot,Command onCommand,Command offCommand){
        onCommands[slot]=onCommand;
        offCommands[slot]=offCommand;
    }
    
    public void onButtonWasPressed(int slot){
        onCommands[slot].execute();
        undoCommand=onCommands[slot];
        
        
       
    }
    public void offButtonWasPressed(int slot){
         offCommands[slot].execute();
        undoCommand=offCommands[slot];
        
    }
    public void undoButtonWasPressed(){
        undoCommand.undo();
    }
}
