/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaasssignment;

/**
 *
 * @author Chamod
 */
public class LivingRoomLight implements Light{
    private int brightness;
    public void on(){
        brightness=100;
        System.out.println("light is on");
    }
    public void off(){
        brightness=0;
        System.out.println("light is off");
    }
    public void dim(int level){
        brightness=level;
        System.out.println("light dim to "+ level);
    }
}
