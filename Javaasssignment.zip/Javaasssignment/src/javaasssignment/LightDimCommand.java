/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaasssignment;

/**
 *
 * @author Chamod
 */
public class LightDimCommand implements Command{
    private Light light;
    private int firstlevel;
    private int nowlevel;
    
    public LightDimCommand(Light light,int nowlevel){
        this.light=light;
        this.nowlevel=nowlevel;
        
    }
    public void execute(){
        firstlevel=light.getBrightness();
        light.dim(nowlevel);
    }
    
    public void undo(){
        light.dim(firstlevel);
    }
    
}
