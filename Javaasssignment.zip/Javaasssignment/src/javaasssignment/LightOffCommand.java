/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaasssignment;

/**
 *
 * @author Chamod
 */
public class LightOffCommand {
    private Light light;
    public LightOffCommand(Light light){
        this.light=light;
    }
    public void execute(){
        light.off();
    }
    public void undo(){
        light.on();
    }
    
}
