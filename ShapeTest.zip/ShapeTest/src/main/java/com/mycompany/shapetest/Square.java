/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shapetest;

/**
 *
 * @author Chamod
 */
public class Square implements Shape {
    public void drow(){
        int length=5;
        for(int i=0;i<length;i=i+1){
           for(int y=0;y<length;y=y+1){
               System.out.print("*");
           }
           System.out.println();
        }
    }
}
