/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shapetest;

/**
 *
 * @author Chamod
 */
public class Triangle implements Shape{
    public void drow(){
        int height=5;
        for(int i=1;i<=height;i=i+1){
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
    
}
