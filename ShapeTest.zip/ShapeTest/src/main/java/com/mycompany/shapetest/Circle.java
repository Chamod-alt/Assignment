/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shapetest;

/**
 *
 * @author Chamod
 */
import java .util.Scanner;
public class Circle implements Shape{
    public void drow() {
            int r = 7;
            int diameter =2*r+1; 
            for (int i = 0; i < diameter; i++) { 
                for (int j=0; j < diameter; j++) { 
                    int x=i-r;
                
             
                int y=j-r;
                        if (x*x+y*y<=r*r+r*0.8) {
                            System.out.print("* ");
                        } 
            else { System.out.print(" "); } 
                        
                }
    System.out.println();
}
    }
}