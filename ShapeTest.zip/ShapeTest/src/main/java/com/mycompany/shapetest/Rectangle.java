/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shapetest;

/**
 *
 * @author Chamod
 */
public class Rectangle implements Shape {
    public void drow(){
        int width=8;
        int height=5;
        for(int i=0;i<width;i=i+1){
            for(int y=0;y<height;y=y+1){
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
