/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.shapetest;

/**
 *
 * @author Chamod
 */
public class ShapeTest {

    public static void main(String[] args) {
         ShapeFactory shapeFactory = new ShapeFactory();

        // Test Square
        Shape square = shapeFactory.getShape("SQUARE");
        if (square != null) {
            System.out.println("Square:");
            square.drow();
            System.out.println();
        }

        // Test Circle
        Shape circle = shapeFactory.getShape("CIRCLE");
        if (circle != null) {
            System.out.println("Circle:");
            circle.drow();
            System.out.println();
        }

        // Test Rectangle
        Shape rectangle = shapeFactory.getShape("RECTANGLE");
        if (rectangle != null) {
            System.out.println("Rectangle:");
            rectangle.drow();
            System.out.println();
        }

        // Test Triangle
        Shape triangle = shapeFactory.getShape("TRIANGLE");
        if (triangle != null) {
            System.out.println("Triangle:");
            triangle.drow();
            System.out.println();
        }

        // Test Invalid Shape
        Shape invalidShape = shapeFactory.getShape("PENTAGON");
        if (invalidShape != null) {
            invalidShape.drow();
        } else {
            System.out.println("Invalid shape type.");
        }
    }
    }

